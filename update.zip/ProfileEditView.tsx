import React, { useState, useEffect, useRef } from 'react';
import {
    User, Briefcase, Heart, Home, Image as ImageIcon, Sparkles,
    Lock, Eye, EyeOff, Mic, Video, Plus, Check, AlertCircle, History,
    Globe, Ruler, Moon, Coffee, Dumbbell, Shield, Umbrella, Loader2, Save,
    FileDown, GraduationCap, Play, Square, Trash2, X, Camera
} from 'lucide-react';
import { api } from '../utils/api';
import { useAuthStore } from '../src/stores/authStore';

interface ProfileEditViewProps {
    initialTab?: string | null;
}

const ProfileEditView: React.FC<ProfileEditViewProps> = ({ initialTab }) => {
    // ... rest of imports

    const [activeTab, setActiveTab] = useState(initialTab || 'basics');
    const [loading, setLoading] = useState(true);
    const [profileData, setProfileData] = useState<any>(null);
    const [saving, setSaving] = useState(false);
    const [qualityScore, setQualityScore] = useState<any | null>(null);

    useEffect(() => {
        if (initialTab) {
            setActiveTab(initialTab);
        }
    }, [initialTab]);

    useEffect(() => {
        fetchProfile();
    }, []);

    const fetchProfile = async () => {
        try {
            setLoading(true);
            const results = await Promise.allSettled([
                api.get('/full-profile'),
                api.get('/member/profile/quality-score'),
            ]);
            const profileRes = results[0].status === 'fulfilled' ? results[0].value : null;
            const qualityRes = results[1].status === 'fulfilled' ? results[1].value : null;
            if (profileRes?.data) {
                setProfileData(profileRes.data);
            }
            setQualityScore(qualityRes?.data?.data ?? null);
        } catch (error) {
            console.error('Failed to fetch profile', error);
        } finally {
            setLoading(false);
        }
    };

    const handleNudgeClick = (action: string) => {
        const lower = action.toLowerCase();
        if (lower.includes('photo') || lower.includes('voice')) setActiveTab('media');
        else if (lower.includes('employment') || lower.includes('career')) setActiveTab('career');
        else if (lower.includes('value') || lower.includes('lifestyle')) setActiveTab('lifestyle');
        else if (lower.includes('preferences') || lower.includes('criteria')) setActiveTab('preferences');
        else if (lower.includes('family')) setActiveTab('family');
        else setActiveTab('basics');
    };

    const updateData = (section: string, field: string, value: any) => {
        setProfileData((prev: any) => ({
            ...prev,
            [section]: {
                ...prev[section],
                [field]: value
            }
        }));
    };

    const handleDownloadBiodata = async () => {
        try {
            const response = await api.get('/profile/download-biodata', {
                responseType: 'blob'
            });
            const blobUrl = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
            window.open(blobUrl, '_blank', 'noopener');
            setTimeout(() => window.URL.revokeObjectURL(blobUrl), 10000);
        } catch (error) {
            console.error('Failed to download biodata', error);
            alert('Failed to download biodata');
        }
    };

    const handleSave = async () => {
        try {
            setSaving(true);
            const response = await api.post('/full-profile/update', profileData);
            if (response.data.result) {
                alert("Profile updated successfully!");
            } else {
                alert(response.data.message || "Failed to save profile");
            }
        } catch (error) {
            console.error('Failed to save profile', error);
            const message = (error as any)?.response?.data?.message || "Failed to save profile";
            alert(message);
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="flex-1 flex items-center justify-center bg-slate-50">
                <div className="text-center">
                    <Loader2 className="animate-spin text-primary mx-auto mb-4" size={40} />
                    <p className="text-slate-500 font-medium">Preparing your professional profile...</p>
                </div>
            </div>
        );
    }

    const tabs = [
        { id: 'basics', label: 'Basics', icon: <User size={18} /> },
        { id: 'lifestyle', label: 'Lifestyle', icon: <Coffee size={18} /> },
        { id: 'career', label: 'Career', icon: <Briefcase size={18} /> },
        { id: 'family', label: 'Family', icon: <Home size={18} /> },
        { id: 'preferences', label: 'Criteria', icon: <Sparkles size={18} /> },
        { id: 'media', label: 'Media', icon: <ImageIcon size={18} /> },
    ];

    return (
        <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-50/50">
            {/* Header */}
            <header className="h-auto py-4 md:py-0 md:h-20 shrink-0 flex flex-col md:flex-row items-start md:items-center justify-between px-4 md:px-8 bg-white border-b border-slate-200 sticky top-0 z-10 gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-slate-900">My Profile</h2>
                    <p className="text-sm text-slate-500">Manage your persona, privacy controls, and partner preferences.</p>
                </div>
                <div className="flex flex-wrap items-center gap-2 md:gap-4 w-full md:w-auto">
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-orange-50 text-orange-700 rounded-full border border-orange-100 text-xs font-bold whitespace-nowrap">
                        <AlertCircle size={14} />
                        <span>Completeness: {qualityScore?.total ?? 0}%</span>
                    </div>
                    <button className="flex items-center gap-2 text-slate-500 hover:text-primary transition-colors text-sm font-medium whitespace-nowrap">
                        <History size={16} />
                        History
                    </button>
                    <button
                        onClick={handleDownloadBiodata}
                        className="flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 rounded-full hover:bg-slate-200 transition-all text-sm font-bold border border-slate-200 shadow-sm"
                    >
                        <FileDown size={16} className="text-slate-500" />
                        Biodata
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={saving}
                        className="flex items-center justify-center gap-2 flex-1 md:flex-none bg-primary hover:bg-primary-hover text-white px-6 py-2 rounded-full font-bold text-sm shadow-md transition-all whitespace-nowrap disabled:opacity-50"
                    >
                        {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                        Save Changes
                    </button>
                </div>
            </header>

            {/* Main Layout */}
            <div className="flex-1 flex overflow-hidden">
                {/* Navigation Tabs */}
                <div className="flex-1 flex flex-col overflow-y-auto p-4 md:p-8 scrollbar-hide">
                    <div className="max-w-5xl mx-auto w-full">

                        {/* Tabs */}
                        <div className="flex gap-2 mb-6 md:mb-8 overflow-x-auto pb-2 scrollbar-hide">
                            {tabs.map(tab => (
                                <button
                                    key={tab.id}
                                    onClick={() => setActiveTab(tab.id)}
                                    className={`
                                flex items-center gap-2 px-4 md:px-5 py-2 md:py-3 rounded-full font-bold text-sm whitespace-nowrap transition-all border
                                ${activeTab === tab.id
                                            ? 'bg-slate-900 text-white border-slate-900 shadow-md'
                                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                                        }
                            `}
                                >
                                    {tab.icon}
                                    {tab.label}
                                </button>
                            ))}
                        </div>

                        {/* Content Area */}
                        <div className="animate-in fade-in slide-in-from-bottom-4 duration-300 pb-8">
                            {activeTab === 'basics' && (
                                <BasicsSection
                                    data={profileData.basics}
                                    optionSets={profileData.optionSets}
                                    updateData={(field, val) => updateData('basics', field, val)}
                                    onRefresh={fetchProfile}
                                />
                            )}
                            {activeTab === 'lifestyle' && (
                                <LifestyleSection
                                    data={profileData.lifestyle}
                                    optionSets={profileData.optionSets}
                                    updateData={(field, val) => updateData('lifestyle', field, val)}
                                />
                            )}
                            {activeTab === 'career' && (
                                <CareerSection
                                    data={profileData.career}
                                    salaryRanges={profileData.salaryRanges}
                                    optionSets={profileData.optionSets}
                                    updateData={(field, val) => updateData('career', field, val)}
                                />
                            )}
                            {activeTab === 'family' && (
                                <FamilySection
                                    data={profileData.family}
                                    optionSets={profileData.optionSets}
                                    updateData={(field, val) => updateData('family', field, val)}
                                />
                            )}
                            {activeTab === 'preferences' && (
                                <PreferencesSection
                                    data={profileData.expectations}
                                    optionSets={profileData.optionSets}
                                    updateData={(field, val) => updateData('expectations', field, val)}
                                />
                            )}
                            {activeTab === 'media' && (
                                <MediaSection
                                    data={profileData.media}
                                    visibility={profileData.visibility}
                                    avatarUrl={profileData.basics.avatarUrl}
                                    onRefresh={fetchProfile}
                                />
                            )}
                        </div>

                    </div>
                </div>

                {/* Quality Sidebar (Right) */}
                <div className="w-80 bg-white border-l border-slate-200 p-6 hidden xl:block overflow-y-auto shrink-0">
                    <h3 className="font-bold text-slate-900 mb-4">Quality Score</h3>
                    <div className="relative pt-1 mb-6">
                        <div className="flex mb-2 items-center justify-between">
                            <div>
                                <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-primary bg-primary/10">
                                    {qualityScore?.level ?? 'N/A'}
                                </span>
                            </div>
                            <div className="text-right">
                                <span className="text-xs font-semibold inline-block text-primary">
                                    {qualityScore?.total ?? 0}%
                                </span>
                            </div>
                        </div>
                        <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-primary/10">
                            <div style={{ width: `${qualityScore?.total ?? 0}%` }} className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary"></div>
                        </div>
                    </div>

                    <h4 className="font-bold text-sm text-slate-800 mb-3">Improve your profile</h4>
                    <div className="space-y-3">
                        {qualityScore?.improvements?.length ? (
                            qualityScore.improvements.map((item: any, index: number) => (
                                <NudgeItem
                                    key={`${item.action}-${index}`}
                                    label={item.action}
                                    points={`+${item.points}%`}
                                    onClick={() => handleNudgeClick(item.action)}
                                />
                            ))
                        ) : (
                            <p className="text-xs text-slate-500">Your profile is in great shape.</p>
                        )}
                    </div>

                    <div className="mt-8 p-4 bg-slate-50 rounded-xl border border-slate-100">
                        <h4 className="font-bold text-xs text-slate-400 uppercase tracking-wide mb-2">Duplicate Check</h4>
                        <div className="flex items-center gap-2 text-green-600 text-sm font-medium">
                            <Check size={16} />
                            <span>No duplicates found</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">We check photos and bio text against our database.</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

/* --- Sub Components for Sections --- */

const normalizeStringList = (value: any): string[] => {
    if (Array.isArray(value)) {
        return value.map((item) => String(item).trim()).filter(Boolean);
    }
    if (typeof value === 'string') {
        return value
            .split(',')
            .map((item) => item.trim())
            .filter(Boolean);
    }
    return [];
};

const resolveOptionValue = (currentValue: any, options: Array<{ value: any; label?: string }>) => {
    if (currentValue === null || currentValue === undefined || currentValue === '') {
        return '';
    }
    const match = options.find((option) => option.value === currentValue || option.label === currentValue);
    return match ? match.value : currentValue;
};

const ensureOptionValue = (currentValue: any, options: Array<{ value: any; label?: string }>) => {
    if (currentValue === null || currentValue === undefined || currentValue === '') {
        return options;
    }
    const exists = options.some((option) => option.value === currentValue || option.label === currentValue);
    if (exists) {
        return options;
    }
    return [{ value: currentValue, label: String(currentValue) }, ...options];
};

const resolveIdByName = (id: any, name: any, options: Array<{ id: any; name: string }>) => {
    if (id !== null && id !== undefined && id !== '') {
        return String(id);
    }
    if (!name) {
        return '';
    }
    const match = options.find(
        (option) => option.name && option.name.toLowerCase() === String(name).toLowerCase()
    );
    return match ? String(match.id) : '';
};

const formatHeightLabel = (heightCm: any) => {
    const numeric = Number(heightCm);
    if (!Number.isFinite(numeric) || numeric <= 0) {
        return '';
    }
    const totalInches = Math.round(numeric / 2.54);
    const feet = Math.floor(totalInches / 12);
    const inches = totalInches % 12;
    return `${feet}'${inches}"`;
};

const BasicsSection: React.FC<{ data: any, optionSets?: any, updateData: (field: string, val: any) => void, onRefresh: () => void }> = ({ data, optionSets, updateData, onRefresh }) => {
    const [uploading, setUploading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { user, setUser } = useAuthStore();

    const avatarUrl = data.avatarUrl || user?.avatar_original || user?.avatar || '';

    const handleAvatarClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('photo', file);

        try {
            setUploading(true);
            const response = await api.post('/upload-profile-picture', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            if (response.data.success || response.data.result) {
                // Update global state
                const newPhotoUrl = response.data.data.photo_url;
                setUser({
                    ...user,
                    avatar: newPhotoUrl,
                    avatar_original: newPhotoUrl
                } as any);

                // Refresh local data
                onRefresh();
                alert("Profile picture updated successfully!");
            }
        } catch (error: any) {
            console.error("Avatar upload failed", error);
            alert(error.response?.data?.message || "Failed to upload profile picture.");
        } finally {
            setUploading(false);
            if (fileInputRef.current) fileInputRef.current.value = '';
        }
    };

    const genderOptions = ensureOptionValue(data?.gender, optionSets?.genders ?? []);
    const marriageTimelineOptions = ensureOptionValue(data?.marriageTimeline, optionSets?.marriageTimeline ?? []);
    const relocationOptions = ensureOptionValue(data?.relocationWillingness, optionSets?.relocationWillingness ?? []);
    const seriousnessOptions = ensureOptionValue(data?.seriousnessLevel, optionSets?.seriousnessLevel ?? []);
    const immigrationOptions = ensureOptionValue(data?.immigrationStatus, optionSets?.immigrationStatusOptions ?? []);
    const countryOptions = optionSets?.countries ?? [];
    const languageOptions = optionSets?.languages ?? [];
    const heightValue = Number.isFinite(Number(data?.height)) ? Number(data.height) : 170;
    const heightLabel = formatHeightLabel(heightValue);

    const [languages, setLanguages] = useState<string[]>(() => {
        return normalizeStringList(data?.languages ?? data?.language);
    });
    const [languageInput, setLanguageInput] = useState('');
    const [stateOptions, setStateOptions] = useState<any[]>([]);
    const [cityOptions, setCityOptions] = useState<any[]>([]);
    const [loadingStates, setLoadingStates] = useState(false);
    const [loadingCities, setLoadingCities] = useState(false);

    useEffect(() => {
        setLanguages(normalizeStringList(data?.languages ?? data?.language));
    }, [data?.languages, data?.language]);

    const applyLanguages = (nextLanguages: string[]) => {
        setLanguages(nextLanguages);
        updateData('languages', nextLanguages);
        updateData('language', nextLanguages.join(', '));
    };

    const handleAddLanguage = () => {
        const nextValue = languageInput.trim();
        if (!nextValue) return;
        if (languages.some((lang) => lang.toLowerCase() === nextValue.toLowerCase())) {
            setLanguageInput('');
            return;
        }
        applyLanguages([...languages, nextValue]);
        setLanguageInput('');
    };

    const handleRemoveLanguage = (label: string) => {
        applyLanguages(languages.filter((lang) => lang !== label));
    };

    useEffect(() => {
        const countryId = data?.currentResidencyCountryId;
        if (!countryId) {
            setStateOptions([]);
            return;
        }
        let isActive = true;
        setLoadingStates(true);
        api.get(`/member/states/${countryId}`)
            .then((response) => {
                if (!isActive) return;
                const payload = response.data?.data ?? response.data ?? [];
                setStateOptions(Array.isArray(payload) ? payload : []);
            })
            .catch(() => {
                if (!isActive) return;
                setStateOptions([]);
            })
            .finally(() => {
                if (!isActive) return;
                setLoadingStates(false);
            });
        return () => {
            isActive = false;
        };
    }, [data?.currentResidencyCountryId]);

    useEffect(() => {
        const stateId = data?.currentResidencyStateId;
        if (!stateId) {
            setCityOptions([]);
            return;
        }
        let isActive = true;
        setLoadingCities(true);
        api.get(`/member/cities/${stateId}`)
            .then((response) => {
                if (!isActive) return;
                const payload = response.data?.data ?? response.data ?? [];
                setCityOptions(Array.isArray(payload) ? payload : []);
            })
            .catch(() => {
                if (!isActive) return;
                setCityOptions([]);
            })
            .finally(() => {
                if (!isActive) return;
                setLoadingCities(false);
            });
        return () => {
            isActive = false;
        };
    }, [data?.currentResidencyStateId]);

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card title="Personal Basics">
                <div className="flex flex-col items-center mb-6 pb-6 border-b border-slate-100">
                    <div className="relative group">
                        <div
                            className={`size-24 rounded-full bg-slate-100 border-4 border-white shadow-xl bg-cover bg-center transition-all cursor-pointer ${uploading ? 'opacity-50' : 'hover:scale-105 hover:brightness-90'}`}
                            style={avatarUrl ? { backgroundImage: `url(${avatarUrl})` } : undefined}
                            onClick={handleAvatarClick}
                        >
                            {!avatarUrl && !uploading && <User size={40} className="text-slate-300 absolute inset-0 m-auto" />}
                        </div>
                        <div
                            onClick={handleAvatarClick}
                            className="absolute bottom-0 right-0 size-8 bg-primary text-white rounded-full flex items-center justify-center shadow-lg cursor-pointer hover:bg-primary-hover transition-colors"
                        >
                            <Camera size={14} />
                        </div>
                        {uploading && (
                            <div className="absolute inset-0 flex items-center justify-center bg-white/40 rounded-full">
                                <Loader2 size={24} className="animate-spin text-primary" />
                            </div>
                        )}
                        <input
                            type="file"
                            ref={fileInputRef}
                            className="hidden"
                            accept="image/*"
                            onChange={handleFileChange}
                        />
                    </div>
                    <p className="text-[10px] font-bold text-slate-400 mt-3 uppercase tracking-widest">Click to change photo</p>
                </div>

                <div className="space-y-4">
                    <InputGroup label="Full Name (Legal)">
                        <input
                            type="text"
                            className="form-input"
                            value={data.firstName ?? ''}
                            onChange={(e) => updateData('firstName', e.target.value)}
                        />
                        <VisibilityToggle />
                    </InputGroup>

                    <div className="grid grid-cols-2 gap-4">
                        <InputGroup label="Date of Birth">
                            <input
                                type="date"
                                className="form-input"
                                value={data.dateOfBirth?.split(' ')[0] ?? ''}
                                onChange={(e) => updateData('dateOfBirth', e.target.value)}
                            />
                        </InputGroup>
                        <InputGroup label="Gender">
                            <select
                                className="form-input"
                                value={resolveOptionValue(data.gender, genderOptions)}
                                onChange={(e) => updateData('gender', e.target.value)}
                            >
                                <option value="">Select gender</option>
                                {genderOptions.map((option: any) => (
                                    <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                                ))}
                            </select>
                        </InputGroup>
                    </div>

                    <InputGroup label="Height">
                        <div className="flex items-center gap-3">
                            <Ruler size={18} className="text-slate-400" />
                            <input
                                type="range"
                                className="flex-1 accent-primary"
                                min="140"
                                max="220"
                                value={heightValue}
                                onChange={(e) => updateData('height', Number(e.target.value))}
                            />
                            <span className="text-sm font-bold text-slate-700 w-16">{heightLabel || "5'7\""}</span>
                        </div>
                    </InputGroup>
                </div>
            </Card>

            <Card title="Origin & Location">
                <div className="space-y-4">
                    <InputGroup label="Languages Spoken">
                        <div className="flex flex-wrap gap-2 items-center">
                            {languages.map((label) => (
                                <Badge key={label} label={label} onRemove={() => handleRemoveLanguage(label)} />
                            ))}
                            <input
                                type="text"
                                value={languageInput}
                                onChange={(e) => setLanguageInput(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        e.preventDefault();
                                        handleAddLanguage();
                                    }
                                }}
                                placeholder="Add language"
                                className="text-xs border border-slate-200 rounded-md px-2 py-1 focus:border-primary focus:outline-none"
                                list="language-options"
                            />
                            <datalist id="language-options">
                                {languageOptions.map((option: any) => (
                                    <option key={option.id} value={option.name} />
                                ))}
                            </datalist>
                            <button
                                type="button"
                                onClick={handleAddLanguage}
                                disabled={!languageInput.trim()}
                                className="text-xs font-bold text-primary flex items-center gap-1 bg-primary/5 px-2 py-1 rounded-md hover:bg-primary/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                <Plus size={12} /> Add
                            </button>
                        </div>
                    </InputGroup>

                    <InputGroup label="Nationality">
                        <div className="flex items-center gap-2 form-input bg-white">
                            <Globe size={16} className="text-slate-400" />
                            <select
                                className="flex-1 bg-transparent outline-none"
                                value={data.nationality ?? ''}
                                onChange={(e) => updateData('nationality', e.target.value)}
                            >
                                <option value="">Select nationality</option>
                                {data.nationality && !countryOptions.some((country: any) => country.name === data.nationality) && (
                                    <option value={data.nationality}>{data.nationality}</option>
                                )}
                                {countryOptions.map((country: any) => (
                                    <option key={country.id ?? country.code} value={country.name}>{country.name}</option>
                                ))}
                            </select>
                        </div>
                    </InputGroup>

                    <InputGroup label="Immigration Status (Optional)">
                        <select
                            className="form-input"
                            value={resolveOptionValue(data.immigrationStatus, immigrationOptions)}
                            onChange={(e) => updateData('immigrationStatus', e.target.value)}
                        >
                            <option value="">Select status</option>
                            {immigrationOptions.map((option: any) => (
                                <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                            ))}
                        </select>
                    </InputGroup>

                    <InputGroup label="Current Residency">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <select
                                className="form-input"
                                value={data.currentResidencyCountryId ?? ''}
                                onChange={(e) => {
                                    const nextValue = e.target.value ? Number(e.target.value) : null;
                                    updateData('currentResidencyCountryId', nextValue);
                                    updateData('currentResidencyStateId', null);
                                    updateData('currentResidencyCityId', null);
                                }}
                            >
                                <option value="">Select country</option>
                                {countryOptions.map((country: any) => (
                                    <option key={country.id ?? country.code} value={country.id}>{country.name}</option>
                                ))}
                            </select>
                            <select
                                className="form-input"
                                value={data.currentResidencyStateId ?? ''}
                                onChange={(e) => {
                                    const nextValue = e.target.value ? Number(e.target.value) : null;
                                    updateData('currentResidencyStateId', nextValue);
                                    updateData('currentResidencyCityId', null);
                                }}
                                disabled={!data.currentResidencyCountryId || loadingStates}
                            >
                                <option value="">{loadingStates ? 'Loading states...' : 'Select state'}</option>
                                {stateOptions.map((state: any) => (
                                    <option key={state.id} value={state.id}>{state.name}</option>
                                ))}
                            </select>
                            <select
                                className="form-input"
                                value={data.currentResidencyCityId ?? ''}
                                onChange={(e) => updateData('currentResidencyCityId', e.target.value ? Number(e.target.value) : null)}
                                disabled={!data.currentResidencyStateId || loadingCities}
                            >
                                <option value="">{loadingCities ? 'Loading cities...' : 'Select city'}</option>
                                {cityOptions.map((city: any) => (
                                    <option key={city.id} value={city.id}>{city.name}</option>
                                ))}
                            </select>
                        </div>
                    </InputGroup>
                </div>
            </Card>

            <div className="md:col-span-2">
                <Card title="Marriage Intent">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <InputGroup label="Timeline">
                            <select
                                className="form-input"
                                value={resolveOptionValue(data.marriageTimeline, marriageTimelineOptions)}
                                onChange={(e) => updateData('marriageTimeline', e.target.value)}
                            >
                                <option value="">Select timeline</option>
                                {marriageTimelineOptions.map((option: any) => (
                                    <option key={option.value} value={option.value}>{option.label}</option>
                                ))}
                            </select>
                        </InputGroup>
                        <InputGroup label="Relocation Willingness">
                            <select
                                className="form-input"
                                value={resolveOptionValue(data.relocationWillingness, relocationOptions)}
                                onChange={(e) => updateData('relocationWillingness', e.target.value)}
                            >
                                <option value="">Select preference</option>
                                {relocationOptions.map((option: any) => (
                                    <option key={option.value} value={option.value}>{option.label}</option>
                                ))}
                            </select>
                        </InputGroup>
                        <InputGroup label="Seriousness">
                            <div className="flex items-center gap-2 form-input bg-green-50 text-green-700 border border-green-200">
                                <Check size={16} />
                                <select
                                    className="flex-1 bg-transparent outline-none text-green-700 font-bold"
                                    value={resolveOptionValue(data.seriousnessLevel, seriousnessOptions)}
                                    onChange={(e) => updateData('seriousnessLevel', e.target.value)}
                                >
                                    <option value="">Select level</option>
                                    {seriousnessOptions.map((option: any) => (
                                        <option key={option.value} value={option.value}>{option.label}</option>
                                    ))}
                                </select>
                            </div>
                        </InputGroup>
                    </div>
                </Card>
            </div>
        </div>
    );
};

const LifestyleSection: React.FC<{ data: any, optionSets?: any, updateData: (field: string, val: any) => void }> = ({ data, optionSets, updateData }) => {
    const dietOptions = ensureOptionValue(data?.diet, optionSets?.dietOptions ?? []);
    const drinkOptions = ensureOptionValue(data?.drink, optionSets?.drinkOptions ?? []);
    const smokeOptions = ensureOptionValue(data?.smoke, optionSets?.smokeOptions ?? []);
    const sleepOptions = ensureOptionValue(data?.sleepSchedule, optionSets?.sleepScheduleOptions ?? []);
    const livingWithOptions = ensureOptionValue(data?.livingWith, optionSets?.livingWithOptions ?? []);
    const personalityOptions = optionSets?.personalityTags ?? [];
    const personalValueOptions = ensureOptionValue(data?.personalValue, optionSets?.personalValues ?? []);
    const communityValueOptions = ensureOptionValue(data?.communityValue, optionSets?.communityValues ?? []);
    const familyValues = optionSets?.familyValues ?? [];

    const [hobbies, setHobbies] = useState<string[]>(() => normalizeStringList(data?.hobbies));
    const [interests, setInterests] = useState<string[]>(() => normalizeStringList(data?.interests));
    const [personalityTags, setPersonalityTags] = useState<string[]>(() => normalizeStringList(data?.personalityTags));
    const [hobbyInput, setHobbyInput] = useState('');
    const [interestInput, setInterestInput] = useState('');
    const [personalityInput, setPersonalityInput] = useState('');

    useEffect(() => {
        setHobbies(normalizeStringList(data?.hobbies));
    }, [data?.hobbies]);

    useEffect(() => {
        setInterests(normalizeStringList(data?.interests));
    }, [data?.interests]);

    useEffect(() => {
        setPersonalityTags(normalizeStringList(data?.personalityTags));
    }, [data?.personalityTags]);

    const applyTagList = (nextList: string[], field: string, setter: React.Dispatch<React.SetStateAction<string[]>>) => {
        setter(nextList);
        updateData(field, nextList);
    };

    const addTag = (value: string, field: string, list: string[], setter: React.Dispatch<React.SetStateAction<string[]>>) => {
        const nextValue = value.trim();
        if (!nextValue) return;
        if (list.some((item) => item.toLowerCase() === nextValue.toLowerCase())) return;
        applyTagList([...list, nextValue], field, setter);
    };

    const removeTag = (value: string, field: string, list: string[], setter: React.Dispatch<React.SetStateAction<string[]>>) => {
        applyTagList(list.filter((item) => item !== value), field, setter);
    };

    const togglePersonalityTag = (value: string) => {
        const exists = personalityTags.some((tag) => tag.toLowerCase() === value.toLowerCase());
        if (exists) {
            applyTagList(personalityTags.filter((tag) => tag.toLowerCase() !== value.toLowerCase()), 'personalityTags', setPersonalityTags);
        } else {
            applyTagList([...personalityTags, value], 'personalityTags', setPersonalityTags);
        }
    };

    const personalityLabel = (value: string) => {
        const match = personalityOptions.find((option: any) => option.value === value || option.label === value);
        return match?.label ?? value;
    };

    return (
        <div className="space-y-6">
            <Card title="Habits & Lifestyle">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <InputGroup label="Dietary Preferences">
                        <select
                            className="form-input"
                            value={resolveOptionValue(data.diet, dietOptions)}
                            onChange={(e) => updateData('diet', e.target.value)}
                        >
                            <option value="">Select diet</option>
                            {dietOptions.map((option: any) => (
                                <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                            ))}
                        </select>
                    </InputGroup>
                    <InputGroup label="Drinking">
                        <select
                            className="form-input"
                            value={resolveOptionValue(data.drink, drinkOptions)}
                            onChange={(e) => updateData('drink', e.target.value)}
                        >
                            <option value="">Select option</option>
                            {drinkOptions.map((option: any) => (
                                <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                            ))}
                        </select>
                    </InputGroup>
                    <InputGroup label="Smoking">
                        <select
                            className="form-input"
                            value={resolveOptionValue(data.smoke, smokeOptions)}
                            onChange={(e) => updateData('smoke', e.target.value)}
                        >
                            <option value="">Select option</option>
                            {smokeOptions.map((option: any) => (
                                <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                            ))}
                        </select>
                    </InputGroup>
                    <InputGroup label="Living With">
                        <select
                            className="form-input"
                            value={resolveOptionValue(data.livingWith, livingWithOptions)}
                            onChange={(e) => updateData('livingWith', e.target.value)}
                        >
                            <option value="">Select arrangement</option>
                            {livingWithOptions.map((option: any) => (
                                <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                            ))}
                        </select>
                    </InputGroup>
                    <InputGroup label="Sleep Schedule">
                        <div className="flex items-center gap-2 form-input">
                            <Moon size={16} className="text-slate-400" />
                            <select
                                className="flex-1 bg-transparent outline-none"
                                value={resolveOptionValue(data.sleepSchedule, sleepOptions)}
                                onChange={(e) => updateData('sleepSchedule', e.target.value)}
                            >
                                <option value="">Select schedule</option>
                                {sleepOptions.map((option: any) => (
                                    <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                                ))}
                            </select>
                        </div>
                    </InputGroup>
                </div>
            </Card>

            <Card title="Personality & Interests">
                <div className="space-y-6">
                    <InputGroup label="Hobbies">
                        <div className="flex flex-wrap gap-2 items-center">
                            {hobbies.map((tag) => (
                                <Badge key={tag} label={tag} color="blue" onRemove={() => removeTag(tag, 'hobbies', hobbies, setHobbies)} />
                            ))}
                            <input
                                type="text"
                                value={hobbyInput}
                                onChange={(e) => setHobbyInput(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        e.preventDefault();
                                        addTag(hobbyInput, 'hobbies', hobbies, setHobbies);
                                        setHobbyInput('');
                                    }
                                }}
                                placeholder="Add hobby"
                                className="text-xs border border-slate-200 rounded-md px-2 py-1 focus:border-primary focus:outline-none"
                            />
                            <button
                                type="button"
                                onClick={() => {
                                    addTag(hobbyInput, 'hobbies', hobbies, setHobbies);
                                    setHobbyInput('');
                                }}
                                disabled={!hobbyInput.trim()}
                                className="text-xs font-bold text-primary flex items-center gap-1 bg-primary/5 px-2 py-1 rounded-md hover:bg-primary/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                <Plus size={12} /> Add
                            </button>
                        </div>
                        <p className="text-xs text-slate-400">Type and press enter to add a hobby.</p>
                    </InputGroup>

                    <InputGroup label="Interests">
                        <div className="flex flex-wrap gap-2 items-center">
                            {interests.map((tag) => (
                                <Badge key={tag} label={tag} color="purple" onRemove={() => removeTag(tag, 'interests', interests, setInterests)} />
                            ))}
                            <input
                                type="text"
                                value={interestInput}
                                onChange={(e) => setInterestInput(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        e.preventDefault();
                                        addTag(interestInput, 'interests', interests, setInterests);
                                        setInterestInput('');
                                    }
                                }}
                                placeholder="Add interest"
                                className="text-xs border border-slate-200 rounded-md px-2 py-1 focus:border-primary focus:outline-none"
                            />
                            <button
                                type="button"
                                onClick={() => {
                                    addTag(interestInput, 'interests', interests, setInterests);
                                    setInterestInput('');
                                }}
                                disabled={!interestInput.trim()}
                                className="text-xs font-bold text-primary flex items-center gap-1 bg-primary/5 px-2 py-1 rounded-md hover:bg-primary/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                <Plus size={12} /> Add
                            </button>
                        </div>
                        <p className="text-xs text-slate-400">Type and press enter to add an interest.</p>
                    </InputGroup>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <label className="block text-sm font-bold text-slate-800 mb-3">Personality Tags (Self-Assessed)</label>
                            <div className="flex flex-wrap gap-2 mb-3">
                                {personalityTags.map((tag) => (
                                    <Badge key={tag} label={personalityLabel(tag)} color="orange" onRemove={() => removeTag(tag, 'personalityTags', personalityTags, setPersonalityTags)} />
                                ))}
                            </div>
                            <div className="flex flex-wrap gap-2">
                                {personalityOptions.map((option: any) => {
                                    const isSelected = personalityTags.some((tag) => tag.toLowerCase() === option.value.toLowerCase());
                                    return (
                                        <button
                                            key={option.value}
                                            type="button"
                                            onClick={() => togglePersonalityTag(option.value)}
                                            className={`px-3 py-1 rounded-full border text-xs transition-colors ${isSelected
                                                ? 'border-primary bg-primary/10 text-primary'
                                                : 'border-slate-200 text-slate-600 hover:border-primary hover:text-primary'
                                                }`}
                                        >
                                            {option.label ?? option.value}
                                        </button>
                                    );
                                })}
                            </div>
                            <div className="mt-3 flex items-center gap-2">
                                <input
                                    type="text"
                                    value={personalityInput}
                                    onChange={(e) => setPersonalityInput(e.target.value)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            e.preventDefault();
                                            addTag(personalityInput, 'personalityTags', personalityTags, setPersonalityTags);
                                            setPersonalityInput('');
                                        }
                                    }}
                                    placeholder="Add custom tag"
                                    className="text-xs border border-slate-200 rounded-md px-2 py-1 focus:border-primary focus:outline-none flex-1"
                                />
                                <button
                                    type="button"
                                    onClick={() => {
                                        addTag(personalityInput, 'personalityTags', personalityTags, setPersonalityTags);
                                        setPersonalityInput('');
                                    }}
                                    disabled={!personalityInput.trim()}
                                    className="text-xs font-bold text-primary bg-primary/5 px-2 py-1 rounded-md hover:bg-primary/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    Add
                                </button>
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-bold text-slate-800 mb-3">Religious / Cultural Values</label>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <select
                                    className="form-input text-sm"
                                    value={resolveOptionValue(data.personalValue, personalValueOptions)}
                                    onChange={(e) => updateData('personalValue', e.target.value)}
                                >
                                    <option value="">Select personal value</option>
                                    {personalValueOptions.map((option: any) => (
                                        <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                                    ))}
                                </select>
                                <select
                                    className="form-input text-sm"
                                    value={resolveOptionValue(data.communityValue, communityValueOptions)}
                                    onChange={(e) => updateData('communityValue', e.target.value)}
                                >
                                    <option value="">Select community value</option>
                                    {communityValueOptions.map((option: any) => (
                                        <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="mt-4">
                                <select
                                    className="form-input text-sm"
                                    value={data.familyValueId ?? ''}
                                    onChange={(e) => updateData('familyValueId', e.target.value ? Number(e.target.value) : null)}
                                >
                                    <option value="">Select family value</option>
                                    {familyValues.map((option: any) => (
                                        <option key={option.id} value={option.id}>{option.name}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </Card>
        </div>
    );
};

const CareerSection: React.FC<{ data: any, salaryRanges?: any[], optionSets?: any, updateData: (field: string, val: any) => void }> = ({ data, salaryRanges = [], optionSets, updateData }) => {
    const workLocationOptions = ensureOptionValue(data?.workLocationType, optionSets?.workLocationOptions ?? []);

    return (
        <div className="space-y-6">
            <Card title="Education & Professional Background">
                <div className="space-y-6">
                    <div className="flex flex-col gap-4">
                        <div className="flex items-start gap-4 p-6 bg-slate-50 rounded-xl border border-slate-100 relative group">
                            <div className="size-12 bg-white rounded-full border border-slate-200 flex items-center justify-center shrink-0 shadow-sm">
                                <GraduationCap size={22} className="text-primary" />
                            </div>
                            <div className="flex-1 space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <InputGroup label="Degree / Qualification">
                                        <input
                                            type="text"
                                            className="form-input bg-white"
                                            placeholder="e.g. Master in Data Science"
                                            defaultValue={data.education}
                                            onBlur={(e) => updateData('education', e.target.value)}
                                        />
                                    </InputGroup>
                                    <InputGroup label="Institution / University">
                                        <input
                                            type="text"
                                            className="form-input bg-white"
                                            placeholder="e.g. Stanford University"
                                            defaultValue={data.institution}
                                            onBlur={(e) => updateData('institution', e.target.value)}
                                        />
                                    </InputGroup>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                    <InputGroup label="Start Year">
                                        <input
                                            type="number"
                                            className="form-input bg-white text-sm"
                                            placeholder="YYYY"
                                            defaultValue={data.educationStart}
                                            onBlur={(e) => updateData('educationStart', e.target.value)}
                                        />
                                    </InputGroup>
                                    <InputGroup label="End Year (or Expected)">
                                        <input
                                            type="number"
                                            className="form-input bg-white text-sm"
                                            placeholder="YYYY"
                                            defaultValue={data.educationEnd}
                                            onBlur={(e) => updateData('educationEnd', e.target.value)}
                                        />
                                    </InputGroup>
                                    <div className="flex items-end pb-3">
                                        <label className="flex items-center gap-2 cursor-pointer group">
                                            <input
                                                type="checkbox"
                                                className="size-4 rounded border-slate-300 text-primary focus:ring-primary"
                                                checked={!!data.isHighestDegree}
                                                onChange={(e) => updateData('isHighestDegree', e.target.checked)}
                                            />
                                            <span className="text-xs font-bold text-slate-600 group-hover:text-primary transition-colors">Highest Degree</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Card>

            <Card title="Current Employment">
                <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <InputGroup label="Profession / Designation">
                            <input
                                type="text"
                                className="form-input"
                                placeholder="e.g. Senior Software Engineer"
                                defaultValue={data.designation}
                                onBlur={(e) => updateData('designation', e.target.value)}
                            />
                        </InputGroup>

                        <InputGroup label="Employer / Hospital (Masked)">
                            <div className="flex gap-2">
                                <input
                                    type="text"
                                    className="form-input flex-1"
                                    placeholder="e.g. Google, Mayo Clinic"
                                    defaultValue={data.company}
                                    onBlur={(e) => updateData('company', e.target.value)}
                                />
                                <div className="flex items-center justify-center px-3 border border-slate-200 rounded-lg bg-slate-50 text-slate-500" title="Masked from public view">
                                    <EyeOff size={18} />
                                </div>
                            </div>
                        </InputGroup>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="grid grid-cols-2 gap-4">
                            <InputGroup label="Start Year">
                                <input
                                    type="number"
                                    className="form-input text-sm"
                                    placeholder="YYYY"
                                    defaultValue={data.careerStart}
                                    onBlur={(e) => updateData('careerStart', e.target.value)}
                                />
                            </InputGroup>
                            <InputGroup label="End Year">
                                <input
                                    type="number"
                                    className="form-input text-sm disabled:bg-slate-50 disabled:text-slate-400"
                                    placeholder="YYYY"
                                    disabled={!!data.careerPresent}
                                    defaultValue={data.careerEnd}
                                    onBlur={(e) => updateData('careerEnd', e.target.value)}
                                />
                            </InputGroup>
                        </div>
                        <div className="flex items-end pb-3">
                            <label className="flex items-center gap-2 cursor-pointer group">
                                <input
                                    type="checkbox"
                                    className="size-4 rounded border-slate-300 text-primary focus:ring-primary"
                                    checked={!!data.careerPresent}
                                    onChange={(e) => updateData('careerPresent', e.target.checked)}
                                />
                                <span className="text-xs font-bold text-slate-600 group-hover:text-primary transition-colors">I currently work here</span>
                            </label>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100">
                        <InputGroup label="Annual Income (Optional)">
                            <div className="flex gap-2">
                                <select
                                    className="form-input flex-1"
                                    value={salaryRanges.length ? String(data.incomeRangeId ?? '') : (data.income ?? '')}
                                    onChange={(e) => {
                                        const value = e.target.value;
                                        if (salaryRanges.length) {
                                            updateData('incomeRangeId', value ? Number(value) : null);
                                            const selected = salaryRanges.find((range: any) => String(range.id) === value);
                                            updateData('income', selected?.label ?? '');
                                        } else {
                                            updateData('income', value);
                                        }
                                    }}
                                >
                                    <option value="">Select Income</option>
                                    {salaryRanges.length ? (
                                        salaryRanges.map((range: any) => (
                                            <option key={range.id} value={range.id}>{range.label}</option>
                                        ))
                                    ) : (
                                        <option value={data.income ?? ''}>{data.income ?? 'No options available'}</option>
                                    )}
                                </select>
                                <div className="flex items-center justify-center px-3 border border-slate-200 rounded-lg bg-slate-50 text-slate-500" title="Visible only to mutual matches">
                                    <Lock size={18} />
                                </div>
                            </div>
                        </InputGroup>

                        <InputGroup label="Work Location">
                            <select
                                className="form-input"
                                value={resolveOptionValue(data.workLocationType, workLocationOptions)}
                                onChange={(e) => updateData('workLocationType', e.target.value)}
                            >
                                <option value="">Select work location</option>
                                {workLocationOptions.map((option: any) => (
                                    <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                                ))}
                            </select>
                        </InputGroup>
                    </div>
                </div>
            </Card>
        </div>
    );
};

const FamilySection: React.FC<{ data: any, optionSets?: any, updateData: (field: string, val: any) => void }> = ({ data, optionSets, updateData }) => {
    const familyTypeOptions = ensureOptionValue(data?.familyType, optionSets?.familyTypeOptions ?? []);
    const religionOptions = optionSets?.religions ?? [];
    const casteOptions = optionSets?.castes ?? [];
    const selectedReligionId = resolveIdByName(data?.religionId, data?.religion, religionOptions);
    const filteredCastes = selectedReligionId
        ? casteOptions.filter((caste: any) => String(caste.religion_id) === selectedReligionId)
        : casteOptions;
    const selectedCasteId = resolveIdByName(data?.casteId, data?.caste, filteredCastes);

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card title="Family Structure">
                <div className="space-y-4">
                    <InputGroup label="Family Type">
                        <select
                            className="form-input"
                            value={resolveOptionValue(data.familyType, familyTypeOptions)}
                            onChange={(e) => updateData('familyType', e.target.value)}
                        >
                            <option value="">Select family type</option>
                            {familyTypeOptions.map((option: any) => (
                                <option key={option.value} value={option.value}>{option.label ?? option.value}</option>
                            ))}
                        </select>
                    </InputGroup>
                    <div className="grid grid-cols-2 gap-4">
                        <InputGroup label="Brothers">
                            <select
                                className="form-input"
                                value={data.brothers ?? 0}
                                onChange={(e) => updateData('brothers', e.target.value)}
                            >
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3+</option>
                            </select>
                        </InputGroup>
                        <InputGroup label="Sisters">
                            <select
                                className="form-input"
                                value={data.sisters ?? 0}
                                onChange={(e) => updateData('sisters', e.target.value)}
                            >
                                <option value="0">0</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3+</option>
                            </select>
                        </InputGroup>
                    </div>
                </div>
            </Card>

            <Card title="Parental Details">
                <div className="space-y-4">
                    <InputGroup label="Father's Occupation">
                        <input
                            type="text"
                            className="form-input"
                            placeholder="e.g. Civil Servant, Doctor, Business"
                            defaultValue={data.fatherOccupation}
                            onBlur={(e) => updateData('fatherOccupation', e.target.value)}
                        />
                    </InputGroup>
                    <InputGroup label="Mother's Occupation">
                        <input
                            type="text"
                            className="form-input"
                            placeholder="e.g. Homemaker, Professor"
                            defaultValue={data.motherOccupation}
                            onBlur={(e) => updateData('motherOccupation', e.target.value)}
                        />
                    </InputGroup>
                    <InputGroup label="Family Location">
                        <input
                            type="text"
                            className="form-input"
                            placeholder="City, State"
                            defaultValue={data.familyLocation}
                            onBlur={(e) => updateData('familyLocation', e.target.value)}
                        />
                    </InputGroup>
                </div>
            </Card>

            <div className="md:col-span-2">
                <Card title="Community & Culture">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <InputGroup label="Religion">
                            <select
                                className="form-input"
                                value={selectedReligionId}
                                onChange={(e) => {
                                    const nextValue = e.target.value ? Number(e.target.value) : null;
                                    updateData('religionId', nextValue);
                                    const selected = religionOptions.find((item: any) => String(item.id) === e.target.value);
                                    updateData('religion', selected?.name ?? '');
                                    updateData('casteId', null);
                                    updateData('caste', '');
                                }}
                            >
                                <option value="">Select religion</option>
                                {religionOptions.map((option: any) => (
                                    <option key={option.id} value={option.id}>{option.name}</option>
                                ))}
                            </select>
                        </InputGroup>
                        <InputGroup label="Sect (Optional)">
                            <input
                                type="text"
                                className="form-input"
                                defaultValue={data.sect}
                                onChange={(e) => updateData('sect', e.target.value)}
                            />
                        </InputGroup>
                        <InputGroup label="Caste / Clan (Optional)">
                            <select
                                className="form-input"
                                value={selectedCasteId}
                                onChange={(e) => {
                                    const nextValue = e.target.value ? Number(e.target.value) : null;
                                    updateData('casteId', nextValue);
                                    const selected = filteredCastes.find((item: any) => String(item.id) === e.target.value);
                                    updateData('caste', selected?.name ?? '');
                                }}
                                disabled={!selectedReligionId}
                            >
                                <option value="">{selectedReligionId ? 'Select caste' : 'Select religion first'}</option>
                                {filteredCastes.map((option: any) => (
                                    <option key={option.id} value={option.id}>{option.name}</option>
                                ))}
                            </select>
                        </InputGroup>
                    </div>
                </Card>
            </div>
        </div>
    );
};

const PreferencesSection: React.FC<{ data: any, optionSets?: any, updateData: (field: string, val: any) => void }> = ({ data, optionSets, updateData }) => {
    const maritalStatusOptions = optionSets?.maritalStatuses ?? [];
    const religionOptions = optionSets?.religions ?? [];
    const languageOptions = optionSets?.languages ?? [];
    const countryOptions = optionSets?.countries ?? [];
    const familyValueOptions = optionSets?.familyValues ?? [];

    const ageRef = useRef<HTMLDivElement>(null);
    const heightRef = useRef<HTMLDivElement>(null);
    const maritalRef = useRef<HTMLDivElement>(null);
    const religionRef = useRef<HTMLDivElement>(null);
    const languageRef = useRef<HTMLDivElement>(null);
    const residenceRef = useRef<HTMLDivElement>(null);

    const scrollTo = (ref: React.RefObject<HTMLDivElement>) => {
        ref.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        ref.current?.classList.add('ring-4', 'ring-primary', 'ring-offset-2', 'bg-primary/5');
        setTimeout(() => ref.current?.classList.remove('ring-4', 'ring-primary', 'ring-offset-2', 'bg-primary/5'), 2000);
    };

    const selectedMaritalStatusId = resolveIdByName(data?.maritalStatusId, data?.marital_status, maritalStatusOptions);
    const selectedReligionId = resolveIdByName(data?.religionId, data?.religion, religionOptions);
    const selectedLanguageId = resolveIdByName(data?.languageId, data?.language, languageOptions);
    const selectedResidenceId = resolveIdByName(data?.residenceCountryId, data?.residence, countryOptions);
    const minHeightValue = Number.isFinite(Number(data?.min_height)) ? Number(data.min_height) : 150;

    const summaryMaritalStatus = data?.marital_status || maritalStatusOptions.find((item: any) => String(item.id) === selectedMaritalStatusId)?.name || 'Any';
    const summaryReligion = data?.religion || religionOptions.find((item: any) => String(item.id) === selectedReligionId)?.name || 'Any';
    const summaryLanguage = data?.language || languageOptions.find((item: any) => String(item.id) === selectedLanguageId)?.name || 'Any';
    const summaryResidence = data?.residence || countryOptions.find((item: any) => String(item.id) === selectedResidenceId)?.name || 'Any';
    const heightSummary = data?.min_height ? `${formatHeightLabel(data.min_height)} and above` : 'Any';

    return (
        <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl flex gap-3">
                <AlertCircle className="text-blue-500 shrink-0 mt-0.5" />
                <div>
                    <h4 className="font-bold text-blue-900 text-sm">Smart Matching</h4>
                    <p className="text-xs text-blue-700 mt-1">
                        Marking criteria as "Dealbreaker" filters out non-matching profiles completely. "Nice to have" affects the match percentage score.
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <Card title="Demographic Preferences">
                    <div className="space-y-6">
                        <InputGroup label="Age Range" innerRef={ageRef}>
                            <div className="flex items-center gap-4">
                                <input
                                    type="number"
                                    className="form-input w-24"
                                    placeholder="Min"
                                    defaultValue={data.min_age}
                                    onBlur={(e) => updateData('min_age', e.target.value)}
                                />
                                <span className="text-slate-400">to</span>
                                <input
                                    type="number"
                                    className="form-input w-24"
                                    placeholder="Max"
                                    defaultValue={data.max_age}
                                    onBlur={(e) => updateData('max_age', e.target.value)}
                                />
                            </div>
                            <ImportanceSelector
                                value={data.age_importance || 'Dealbreaker'}
                                onChange={(val) => updateData('age_importance', val)}
                            />
                        </InputGroup>

                        <InputGroup label="Minimum Height" innerRef={heightRef}>
                            <div className="flex items-center gap-3">
                                <Ruler size={18} className="text-slate-400" />
                                <input
                                    type="range"
                                    className="flex-1 accent-primary"
                                    min="140"
                                    max="220"
                                    value={minHeightValue}
                                    onChange={(e) => updateData('min_height', Number(e.target.value))}
                                />
                                <span className="text-sm font-bold text-slate-700 w-16">{formatHeightLabel(minHeightValue)}</span>
                            </div>
                            <ImportanceSelector
                                value={data.height_importance || 'Nice to have'}
                                onChange={(val) => updateData('height_importance', val)}
                            />
                        </InputGroup>

                        <InputGroup label="Marital Status" innerRef={maritalRef}>
                            <select
                                className="form-input"
                                value={selectedMaritalStatusId}
                                onChange={(e) => {
                                    const nextValue = e.target.value ? Number(e.target.value) : null;
                                    updateData('maritalStatusId', nextValue);
                                    const selected = maritalStatusOptions.find((item: any) => String(item.id) === e.target.value);
                                    updateData('marital_status', selected?.name ?? '');
                                }}
                            >
                                <option value="">Any</option>
                                {maritalStatusOptions.map((option: any) => (
                                    <option key={option.id} value={option.id}>{option.name}</option>
                                ))}
                            </select>
                            <ImportanceSelector
                                value={data.marital_status_importance || 'Dealbreaker'}
                                onChange={(val) => updateData('marital_status_importance', val)}
                            />
                        </InputGroup>
                    </div>
                </Card>

                <Card title="Cultural & Lifestyle">
                    <div className="space-y-6">
                        <InputGroup label="Religion" innerRef={religionRef}>
                            <select
                                className="form-input"
                                value={selectedReligionId}
                                onChange={(e) => {
                                    const nextValue = e.target.value ? Number(e.target.value) : null;
                                    updateData('religionId', nextValue);
                                    const selected = religionOptions.find((item: any) => String(item.id) === e.target.value);
                                    updateData('religion', selected?.name ?? '');
                                }}
                            >
                                <option value="">Any</option>
                                {religionOptions.map((option: any) => (
                                    <option key={option.id} value={option.id}>{option.name}</option>
                                ))}
                            </select>
                            <ImportanceSelector
                                value={data.religion_importance || 'Must have'}
                                onChange={(val) => updateData('religion_importance', val)}
                            />
                        </InputGroup>

                        <InputGroup label="Preferred Language" innerRef={languageRef}>
                            <select
                                className="form-input"
                                value={selectedLanguageId}
                                onChange={(e) => {
                                    const nextValue = e.target.value ? Number(e.target.value) : null;
                                    updateData('languageId', nextValue);
                                    const selected = languageOptions.find((item: any) => String(item.id) === e.target.value);
                                    updateData('language', selected?.name ?? '');
                                }}
                            >
                                <option value="">Any</option>
                                {languageOptions.map((option: any) => (
                                    <option key={option.id} value={option.id}>{option.name}</option>
                                ))}
                            </select>
                            <ImportanceSelector
                                value={data.language_importance || 'Nice to have'}
                                onChange={(val) => updateData('language_importance', val)}
                            />
                        </InputGroup>

                        <InputGroup label="Preferred Residence Country" innerRef={residenceRef}>
                            <select
                                className="form-input"
                                value={selectedResidenceId}
                                onChange={(e) => {
                                    const nextValue = e.target.value ? Number(e.target.value) : null;
                                    updateData('residenceCountryId', nextValue);
                                    const selected = countryOptions.find((item: any) => String(item.id) === e.target.value);
                                    updateData('residence', selected?.name ?? '');
                                }}
                            >
                                <option value="">Any</option>
                                {countryOptions.map((option: any) => (
                                    <option key={option.id ?? option.code} value={option.id}>{option.name}</option>
                                ))}
                            </select>
                            <ImportanceSelector
                                value={data.residence_importance || 'Nice to have'}
                                onChange={(val) => updateData('residence_importance', val)}
                            />
                        </InputGroup>

                        <InputGroup label="Family Values">
                            <select
                                className="form-input"
                                value={data.familyValueId ?? ''}
                                onChange={(e) => updateData('familyValueId', e.target.value ? Number(e.target.value) : null)}
                            >
                                <option value="">Any</option>
                                {familyValueOptions.map((option: any) => (
                                    <option key={option.id} value={option.id}>{option.name}</option>
                                ))}
                            </select>
                        </InputGroup>
                    </div>
                </Card>
            </div>

            <div className="space-y-3">
                <h4 className="font-bold text-slate-900 text-sm mb-2">Summary of Match Rules</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <PreferenceItem
                        label="Age Range"
                        value={`${data.min_age || 20} - ${data.max_age || 40} Years`}
                        type={data.age_importance || 'Dealbreaker'}
                        onEdit={() => scrollTo(ageRef)}
                    />
                    <PreferenceItem
                        label="Height"
                        value={heightSummary}
                        type={data.height_importance || 'Nice to have'}
                        onEdit={() => scrollTo(heightRef)}
                    />
                    <PreferenceItem
                        label="Marital Status"
                        value={summaryMaritalStatus}
                        type={data.marital_status_importance || 'Dealbreaker'}
                        onEdit={() => scrollTo(maritalRef)}
                    />
                    <PreferenceItem
                        label="Religion"
                        value={summaryReligion}
                        type={data.religion_importance || 'Must have'}
                        onEdit={() => scrollTo(religionRef)}
                    />
                    <PreferenceItem
                        label="Language"
                        value={summaryLanguage}
                        type={data.language_importance || 'Nice to have'}
                        onEdit={() => scrollTo(languageRef)}
                    />
                    <PreferenceItem
                        label="Residence"
                        value={summaryResidence}
                        type={data.residence_importance || 'Nice to have'}
                        onEdit={() => scrollTo(residenceRef)}
                    />
                </div>

                <div className="pt-4">
                    <button className="w-full py-3 border-2 border-dashed border-slate-200 rounded-xl text-slate-400 font-bold text-sm hover:border-primary hover:text-primary transition-colors flex items-center justify-center gap-2 group">
                        <Plus size={18} className="group-hover:scale-110 transition-transform" /> Add Preference Criteria
                    </button>
                </div>
            </div>
        </div>
    );
};

const VoiceIntroRecorder: React.FC<{
    existingUrl?: string,
    onUpload: (file: File) => Promise<void>,
    onDelete: () => Promise<void>
}> = ({ existingUrl, onUpload, onDelete }) => {
    const [isRecording, setIsRecording] = useState(false);
    const [recordingTime, setRecordingTime] = useState(0);
    const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
    const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
    const [audioUrl, setAudioUrl] = useState<string | null>(existingUrl || null);
    const [isUploading, setIsUploading] = useState(false);
    const timerRef = useRef<NodeJS.Timeout | null>(null);

    // Update audioUrl when existingUrl changes
    useEffect(() => {
        if (existingUrl) setAudioUrl(existingUrl);
    }, [existingUrl]);

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const recorder = new MediaRecorder(stream);
            const chunks: Blob[] = [];

            recorder.ondataavailable = (e) => chunks.push(e.data);
            recorder.onstop = () => {
                const blob = new Blob(chunks, { type: 'audio/webm' });
                setAudioBlob(blob);
                setAudioUrl(URL.createObjectURL(blob));
            };

            recorder.start();
            setMediaRecorder(recorder);
            setIsRecording(true);
            setRecordingTime(0);
            timerRef.current = setInterval(() => {
                setRecordingTime(prev => {
                    if (prev >= 30) {
                        stopRecording();
                        return 30;
                    }
                    return prev + 1;
                });
            }, 1000);
        } catch (err) {
            console.error("Error accessing microphone:", err);
            alert("Could not access microphone. Ensure you are on a secure connection (HTTPS) and have granted permission.");
        }
    };

    const stopRecording = () => {
        if (mediaRecorder && isRecording) {
            mediaRecorder.stop();
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
            setIsRecording(false);
            if (timerRef.current) clearInterval(timerRef.current);
        }
    };

    const handleUpload = async () => {
        if (!audioBlob) return;
        setIsUploading(true);
        try {
            const file = new File([audioBlob], "voice_intro.webm", { type: "audio/webm" });
            await onUpload(file);
            setAudioBlob(null);
        } catch (err) {
            console.error("Upload failed", err);
        } finally {
            setIsUploading(false);
        }
    };

    const handleCancel = () => {
        setAudioBlob(null);
        setAudioUrl(existingUrl || null);
    };

    return (
        <div className="p-4 bg-purple-50 rounded-xl border border-purple-100">
            <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                    <div className={`size-10 rounded-full flex items-center justify-center ${isRecording ? 'bg-red-100 text-red-600 animate-pulse' : 'bg-purple-100 text-purple-600'}`}>
                        {isRecording ? <Square size={20} /> : <Mic size={20} />}
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-900 text-sm">Voice Intro</h4>
                        <p className="text-xs text-slate-500">
                            {isRecording ? `Recording... ${recordingTime}s / 30s` : audioBlob ? "Recording complete. Preview below." : "Record a 30s greeting for matches."}
                        </p>
                    </div>
                </div>
                {!isRecording && !audioBlob && !existingUrl && (
                    <button
                        onClick={startRecording}
                        className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-purple-600 shadow-sm hover:bg-slate-50"
                    >
                        Record
                    </button>
                )}
                {isRecording && (
                    <button
                        onClick={stopRecording}
                        className="px-4 py-2 bg-red-500 text-white rounded-lg text-xs font-bold shadow-sm hover:bg-red-600"
                    >
                        Stop
                    </button>
                )}
            </div>

            {(audioUrl || audioBlob) && !isRecording && (
                <div className="mt-4 flex flex-col gap-3">
                    <audio src={audioUrl || ''} controls className="w-full h-8" />
                    <div className="flex gap-2 justify-end">
                        {audioBlob ? (
                            <>
                                <button
                                    onClick={handleCancel}
                                    className="px-3 py-1.5 bg-slate-100 text-slate-600 rounded-lg text-[10px] font-bold hover:bg-slate-200"
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={handleUpload}
                                    disabled={isUploading}
                                    className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-[10px] font-bold hover:bg-purple-700 disabled:opacity-50 flex items-center gap-1"
                                >
                                    {isUploading ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
                                    Upload
                                </button>
                            </>
                        ) : (
                            <button
                                onClick={onDelete}
                                className="px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-[10px] font-bold hover:bg-red-100 flex items-center gap-1"
                            >
                                <Trash2 size={12} /> Delete
                            </button>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

const MediaSection: React.FC<{ data: any, visibility: any, avatarUrl: string, onRefresh: () => void }> = ({ data, visibility, avatarUrl, onRefresh }) => {
    const [uploading, setUploading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const vaultInputRef = useRef<HTMLInputElement>(null);

    const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, privacy: string = 'public') => {
        const file = e.target.files?.[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('gallery_image', file);
        formData.append('privacy_level', privacy);

        try {
            setUploading(true);
            await api.post('/member/gallery-image', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            onRefresh();
        } catch (error) {
            console.error('Failed to upload image', error);
        } finally {
            setUploading(false);
        }
    };

    const handleDelete = async (id: number) => {
        if (!confirm('Are you sure you want to delete this image?')) return;
        try {
            await api.delete(`/member/gallery-image/${id}`);
            onRefresh();
        } catch (error) {
            console.error('Failed to delete image', error);
        }
    };

    const handleTogglePrivacy = async (imgId: number, currentPrivacy: string) => {
        const newPrivacy = currentPrivacy === 'vault' ? 'public' : 'vault';
        try {
            await api.post('/member/profile/section/media', {
                gallery: [
                    { id: imgId, privacy_level: newPrivacy }
                ]
            });
            onRefresh();
        } catch (error) {
            console.error('Failed to update privacy', error);
        }
    };

    const handleSetMain = async (imgId: number) => {
        try {
            await api.post('/member/profile/section/media', {
                gallery: [
                    { id: imgId, is_main: true }
                ]
            });
            onRefresh();
        } catch (error) {
            console.error('Failed to set main photo', error);
        }
    };

    const handleToggleVisibility = async (fieldName: string, currentValue: boolean) => {
        try {
            await api.post('/member/profile/visibility', {
                field_name: fieldName,
                is_visible: !currentValue
            });
            onRefresh();
        } catch (error) {
            console.error('Failed to update visibility', error);
        }
    };

    const publicGallery = data.gallery?.filter((img: any) => img.privacy_level !== 'vault') || [];
    const vaultGallery = data.gallery?.filter((img: any) => img.privacy_level === 'vault') || [];

    const isVaultActive = visibility?.private_vault !== false; // Default to true
    const isWatermarkActive = visibility?.screenshot_deterrence !== false;

    return (
        <div className="space-y-8">
            <div>
                <div className="flex justify-between items-end mb-4">
                    <h3 className="font-bold text-slate-900">Public Gallery</h3>
                    <span className="text-xs text-slate-500">Visible to accepted matches</span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {/* Gallery Photos */}
                    {publicGallery.map((img: any) => (
                        <div key={img.id} className="aspect-[3/4] rounded-xl bg-slate-100 overflow-hidden relative group">
                            <img src={img.url} className="w-full h-full object-cover" alt="Gallery" />

                            {img.is_main && (
                                <div className="absolute bottom-2 left-2 bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm">Main</div>
                            )}

                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                                {!img.is_main && (
                                    <button
                                        onClick={() => handleSetMain(img.id)}
                                        className="bg-white text-slate-900 px-3 py-1 rounded-full text-[10px] font-bold hover:bg-primary hover:text-white transition-colors"
                                    >
                                        Set Main
                                    </button>
                                )}
                                <button
                                    onClick={() => handleTogglePrivacy(img.id, 'public')}
                                    className="bg-white/20 text-white backdrop-blur-md border border-white/30 px-3 py-1 rounded-full text-[10px] font-bold hover:bg-white/40 transition-colors"
                                >
                                    Move to Vault
                                </button>
                                <button
                                    onClick={() => handleDelete(img.id)}
                                    className="bg-red-500 text-white p-1.5 rounded-full hover:bg-red-600 transition-colors"
                                >
                                    <Plus size={14} className="rotate-45" />
                                </button>
                            </div>
                        </div>
                    ))}

                    {/* Add Photo Placeholder */}
                    <div
                        onClick={() => fileInputRef.current?.click()}
                        className="aspect-[3/4] rounded-xl bg-slate-100 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:border-primary hover:text-primary hover:bg-primary/5 cursor-pointer transition-colors"
                    >
                        {uploading ? (
                            <Loader2 size={24} className="animate-spin" />
                        ) : (
                            <>
                                <ImageIcon size={24} />
                                <span className="text-xs font-bold mt-2">Add Photo</span>
                            </>
                        )}
                        <input
                            type="file"
                            ref={fileInputRef}
                            className="hidden"
                            accept="image/*"
                            onChange={(e) => handleFileUpload(e, 'public')}
                        />
                    </div>
                </div>
            </div>

            <div className="pt-6 border-t border-slate-200">
                <div className="flex justify-between items-start mb-6">
                    <div>
                        <div className="flex items-center gap-2">
                            <Lock size={18} className="text-primary" />
                            <h3 className="font-bold text-slate-900">Private Vault</h3>
                        </div>
                        <p className="text-xs text-slate-500 mt-1">Media here requires specific request approval to view. Watermarked automatically.</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-500">Vault Active</span>
                        <div
                            onClick={() => handleToggleVisibility('private_vault', isVaultActive)}
                            className={`w-8 h-4 ${isVaultActive ? 'bg-primary' : 'bg-slate-300'} rounded-full relative cursor-pointer`}
                        >
                            <div className={`absolute ${isVaultActive ? 'right-0.5' : 'left-0.5'} top-0.5 size-3 bg-white rounded-full transition-all`}></div>
                        </div>
                    </div>
                </div>

                <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 ${!isVaultActive ? 'opacity-50 grayscale pointer-events-none' : ''}`}>
                    {/* Vault Photos */}
                    {vaultGallery.map((img: any) => (
                        <div key={img.id} className="aspect-[3/4] rounded-xl bg-slate-800 overflow-hidden relative group">
                            <img src={img.url} className="w-full h-full object-cover opacity-60 grayscale" alt="Vault" />
                            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                <Lock size={20} className="text-white/40" />
                            </div>

                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                                <button
                                    onClick={() => handleTogglePrivacy(img.id, 'vault')}
                                    className="bg-white text-slate-900 px-3 py-1 rounded-full text-[10px] font-bold hover:bg-primary hover:text-white transition-colors"
                                >
                                    Make Public
                                </button>
                                <button
                                    onClick={() => handleDelete(img.id)}
                                    className="bg-red-500 text-white p-1.5 rounded-full hover:bg-red-600 transition-colors"
                                >
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        </div>
                    ))}

                    <div
                        onClick={() => vaultInputRef.current?.click()}
                        className="aspect-[3/4] rounded-xl bg-slate-100 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:border-slate-400 cursor-pointer"
                    >
                        {uploading ? (
                            <Loader2 size={24} className="animate-spin" />
                        ) : (
                            <>
                                <Plus size={24} />
                                <span className="text-xs font-bold mt-2">Add to Vault</span>
                            </>
                        )}
                        <input
                            type="file"
                            ref={vaultInputRef}
                            className="hidden"
                            accept="image/*"
                            onChange={(e) => handleFileUpload(e, 'vault')}
                        />
                    </div>
                </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <Umbrella size={20} className="text-slate-400" />
                <div className="flex-1">
                    <h4 className="text-sm font-bold text-slate-900">Screenshot Deterrence</h4>
                    <p className="text-xs text-slate-500">Watermarks are active on all your photos.</p>
                </div>
                <div
                    onClick={() => handleToggleVisibility('screenshot_deterrence', isWatermarkActive)}
                    className={`w-8 h-4 ${isWatermarkActive ? 'bg-primary' : 'bg-slate-300'} rounded-full relative cursor-pointer`}
                >
                    <div className={`absolute ${isWatermarkActive ? 'right-0.5' : 'left-0.5'} top-0.5 size-3 bg-white rounded-full transition-all`}></div>
                </div>
            </div>

            <VoiceIntroRecorder
                existingUrl={data.voice_intro_url}
                onUpload={async (file) => {
                    const formData = new FormData();
                    formData.append('voice_file', file);
                    await api.post('/member/profile/media/voice', formData, {
                        headers: { 'Content-Type': 'multipart/form-data' }
                    });
                    onRefresh();
                }}
                onDelete={async () => {
                    if (!confirm('Are you sure you want to delete your voice intro?')) return;
                    await api.delete('/member/profile/media/voice');
                    onRefresh();
                }}
            />
        </div>
    );
};

/* --- Helper Components --- */

const Card: React.FC<{ title: string, children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h3 className="font-bold text-slate-900 mb-6 pb-2 border-b border-slate-100">{title}</h3>
        {children}
    </div>
);

const InputGroup: React.FC<{ label: string, children: React.ReactNode, innerRef?: React.RefObject<HTMLDivElement> }> = ({ label, children, innerRef }) => (
    <div ref={innerRef} className="transition-all duration-500 rounded-lg">
        <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wide">{label}</label>
        {children}
    </div>
);

const Badge: React.FC<{ label: string, color?: string, onRemove: () => void }> = ({ label, color = 'slate', onRemove }) => {
    const colors: Record<string, string> = {
        slate: 'bg-slate-100 text-slate-700',
        pink: 'bg-pink-50 text-pink-700',
        purple: 'bg-purple-50 text-purple-700',
        blue: 'bg-blue-50 text-blue-700',
        orange: 'bg-orange-50 text-orange-700',
    };
    return (
        <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${colors[color]}`}>
            {label}
            <button onClick={onRemove} className="hover:opacity-75"><User size={0} className="hidden" />x</button>
        </span>
    );
};

const VisibilityToggle = () => (
    <div className="flex items-center gap-2 mt-1">
        <div className="flex items-center gap-1 text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded cursor-pointer border border-green-100">
            <Eye size={10} /> Visible
        </div>
    </div>
);

const PreferenceItem: React.FC<{
    label: string,
    value: string,
    type: string,
    onEdit?: () => void
}> = ({ label, value, type, onEdit }) => {
    const typeColors: Record<string, string> = {
        'Must have': 'bg-blue-100 text-blue-700',
        'Nice to have': 'bg-green-100 text-green-700',
        'Dealbreaker': 'bg-red-100 text-red-700',
    };

    return (
        <div className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl hover:border-slate-300 transition-colors group">
            <div>
                <p className="text-xs text-slate-400 font-bold uppercase">{label}</p>
                <p className="font-bold text-slate-900">{value}</p>
            </div>
            <div className="flex items-center gap-3">
                <span className={`text-[10px] font-black uppercase px-2 py-1 rounded ${typeColors[type] || 'bg-slate-100 text-slate-600'}`}>
                    {type}
                </span>
                <button
                    onClick={onEdit}
                    className="text-slate-300 hover:text-primary transition-colors p-1"
                    title="Edit Rule"
                >
                    <UserCogIcon />
                </button>
            </div>
        </div>
    );
}

const ImportanceSelector: React.FC<{ value: string, onChange: (val: string) => void }> = ({ value, onChange }) => {
    const levels = ['Dealbreaker', 'Must have', 'Nice to have'];
    const colors: Record<string, string> = {
        'Dealbreaker': 'bg-red-500',
        'Must have': 'bg-blue-500',
        'Nice to have': 'bg-green-500',
    };

    return (
        <div className="flex gap-2 mt-2">
            {levels.map(level => (
                <button
                    key={level}
                    type="button"
                    onClick={() => onChange(level)}
                    className={`text-[10px] font-bold uppercase px-2 py-1 rounded transition-all ${value === level
                        ? `${colors[level]} text-white shadow-sm ring-1 ring-offset-1 ring-${colors[level]?.split('-')[1]}-200`
                        : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                >
                    {level}
                </button>
            ))}
        </div>
    );
};

const NudgeItem: React.FC<{ label: string, points: string, onClick?: () => void }> = ({ label, points, onClick }) => (
    <div
        onClick={onClick}
        className="flex items-center justify-between p-2 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer group"
    >
        <div className="flex items-center gap-2">
            <div className="size-1.5 rounded-full bg-orange-400"></div>
            <span className="text-sm text-slate-600 group-hover:text-primary transition-colors">{label}</span>
        </div>
        <span className="text-xs font-bold text-green-600">{points}</span>
    </div>
);

// Icon Wrappers for simple usage in maps
const InfoIcon = ({ className }: { className?: string }) => <svg className={`w-5 h-5 ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const UserCogIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>;

/* Styles for Inputs */
const styles = `
    .form-input {
        @apply w-full px-4 py-2.5 rounded-lg border border-slate-300 text-slate-900 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary/20 bg-white;
    }
`;

export default ProfileEditView;
