import React, { useEffect, useState } from 'react';
import { Compass, UserCheck, Heart, MessageSquare, Route, Users, Globe, Bell, UserCircle, ShieldCheck, LogOut, HeartPulse, X, Camera, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { BTN_TAP } from '../utils/motion';
import { api } from '../utils/api';
import { useAuthStore } from '../src/stores/authStore';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onUpgrade?: () => void;
  onCloseMobile?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate, onUpgrade, onCloseMobile }) => {
  const { user, setUser } = useAuthStore();
  const [counts, setCounts] = useState({
    agentPicks: 0,
    proposals: 0,
    messages: 0,
    notifications: 0,
  });
  const [uploading, setUploading] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("Photo size must not exceed 5MB");
      return;
    }

    const formData = new FormData();
    formData.append('photo', file);

    try {
      setUploading(true);
      const response = await api.post('/upload-profile-picture', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      if (response.data.success || response.data.result) {
        const updatedUser = {
          ...user,
          avatar: response.data.data.photo_url,
          avatar_original: response.data.data.photo_url,
          photo_approved: !response.data.data.requires_approval
        };
        setUser(updatedUser as any);
        alert(response.data.message || "Profile picture uploaded successfully!");
      }
    } catch (error: any) {
      console.error("Avatar upload failed", error);
      alert(error.response?.data?.message || "Failed to upload profile picture.");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  useEffect(() => {
    let isActive = true;

    const fetchCounts = async () => {
      const results = await Promise.allSettled([
        api.get('/discovery'),
        api.get('/member/my-interests'),
        api.get('/member/chat-list'),
        api.get('/member/notifications/feed'),
      ]);

      if (!isActive) return;

      const discoveryRes = results[0].status === 'fulfilled' ? results[0].value : null;
      const interestsRes = results[1].status === 'fulfilled' ? results[1].value : null;
      const chatsRes = results[2].status === 'fulfilled' ? results[2].value : null;
      const notificationsRes = results[3].status === 'fulfilled' ? results[3].value : null;

      const agentPicks = discoveryRes?.data?.data?.agent_picks?.length ?? 0;
      const proposals = interestsRes?.data?.meta?.total ?? interestsRes?.data?.data?.length ?? 0;
      const messages = (chatsRes?.data?.data ?? []).reduce((sum: number, thread: any) => {
        const count = Number(thread?.unseen_message_count ?? 0);
        return sum + (Number.isFinite(count) ? count : 0);
      }, 0);
      const notifications = notificationsRes?.data?.unread_count ?? 0;

      setCounts({ agentPicks, proposals, messages, notifications });
    };

    fetchCounts();
    const interval = setInterval(fetchCounts, 30000);

    return () => {
      isActive = false;
      clearInterval(interval);
    };
  }, []);

  const avatarUrl = user?.avatar_original || user?.avatar || '';
  const displayName = user?.name ?? 'Member';
  const membershipLabel = user?.membership === 2 ? 'Premium Member' : 'Basic Member';

  return (
    <aside className="w-[280px] h-full flex flex-col bg-white border-r border-slate-200 shrink-0 relative shadow-xl lg:shadow-none">
      <div className="h-20 flex items-center justify-between px-6 shrink-0">
        <motion.div whileTap={BTN_TAP} className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('dashboard')}>
          <img src="/logo-v2.png" alt="Doctors Marriage Bureau" className="h-10 w-auto" />
        </motion.div>
        <button onClick={onCloseMobile} className="lg:hidden p-2 text-slate-400 hover:text-slate-600">
          <X size={24} />
        </button>
      </div>

      <nav className="flex-1 flex flex-col px-4 gap-1 py-4 overflow-y-auto scrollbar-hide pb-24">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 p-4 bg-slate-50/80 rounded-2xl flex items-center gap-3 border border-slate-100"
        >
          <div className="relative group">
            <div
              className={`size-10 rounded-full bg-slate-200 bg-cover bg-center border border-white shadow-sm transition-all cursor-pointer ${uploading ? 'opacity-50' : 'group-hover:brightness-90'}`}
              style={avatarUrl ? { backgroundImage: `url(${avatarUrl})` } : undefined}
              onClick={handleAvatarClick}
            />
            <div
              onClick={handleAvatarClick}
              className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity bg-black/20 rounded-full"
            >
              <Camera size={14} className="text-white" />
            </div>
            {uploading && (
              <div className="absolute inset-0 flex items-center justify-center bg-white/40 rounded-full">
                <Loader2 size={14} className="animate-spin text-primary" />
              </div>
            )}
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*"
              onChange={handleFileChange}
            />
          </div>
          <div className="overflow-hidden">
            <h2 className="text-sm font-bold text-slate-900 truncate">{displayName}</h2>
            <p className="text-xs text-slate-500 truncate">{membershipLabel}</p>
          </div>
        </motion.div>

        <div className="space-y-1">
          <NavItem icon={<Compass size={20} />} label="Explore Profiles" active={currentView === 'discovery'} onClick={() => onNavigate('discovery')} />
          <NavItem icon={<UserCheck size={20} />} label="Agent Picks" active={currentView === 'agent_picks'} onClick={() => onNavigate('agent_picks')} badge={counts.agentPicks || undefined} />
          <NavItem icon={<Heart size={20} />} label="Sent Proposals" active={currentView === 'dashboard'} onClick={() => onNavigate('dashboard')} badge={counts.proposals || undefined} />
          <NavItem icon={<MessageSquare size={20} />} label="Messages" active={currentView === 'messages'} onClick={() => onNavigate('messages')} badge={counts.messages || undefined} />
        </div>

        <p className="px-4 text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 mt-8">Family & Social</p>
        <div className="space-y-1">
          <NavItem icon={<Users size={20} />} label="Family Portal" active={currentView === 'family'} onClick={() => onNavigate('family')} />
          <NavItem icon={<Globe size={20} />} label="Communities" active={currentView === 'communities'} onClick={() => onNavigate('communities')} />
          <NavItem icon={<Route size={20} />} label="Journey Tracking" active={currentView === 'progression'} onClick={() => onNavigate('progression')} />
        </div>

        <p className="px-4 text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 mt-8">Settings</p>
        <div className="space-y-1">
          <NavItem icon={<Bell size={20} />} label="Notifications" active={currentView === 'notifications'} onClick={() => onNavigate('notifications')} badge={counts.notifications || undefined} />
          <NavItem icon={<UserCircle size={20} />} label="My Profile" active={currentView === 'profile'} onClick={() => onNavigate('profile')} />
          <NavItem icon={<ShieldCheck size={20} />} label="Privacy & Trust" active={currentView === 'settings'} onClick={() => onNavigate('settings')} />
        </div>
      </nav>

      <div className="absolute bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-100">
        <button onClick={() => onNavigate('signout')} className="flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all w-full font-bold text-sm">
          <LogOut size={18} /> Sign Out
        </button>
      </div>
    </aside>
  );
};

const NavItem = ({ icon, label, active, badge, onClick }: any) => (
  <motion.button
    onClick={onClick}
    whileHover={{ scale: 1.02, x: 4 }}
    whileTap={{ scale: 0.98 }}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm ${active ? 'bg-primary/5 text-primary' : 'text-slate-600 hover:bg-slate-50'}`}
  >
    <span className={active ? 'text-primary' : 'text-slate-400'}>{icon}</span>
    <span className="flex-1 text-left">{label}</span>
    {badge && <span className="text-[10px] bg-primary text-white font-bold px-1.5 py-0.5 rounded-md">{badge}</span>}
  </motion.button>
);

export default Sidebar;
